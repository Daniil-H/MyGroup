﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyGroup
{
    public partial class Menu : Form
    {
        public Menu()
        {
            InitializeComponent();
        }
        
        private void formMain_Load(object sender, EventArgs e)
        {
            
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            
            if (tbFamilia.Text != "" && tbImya.Text != "" && tbOtchestvo.Text != "" && tbAdres.Text != "" && tbNumberPhone.Text != "")
            {
                gridMenu.Rows.Add(tbFamilia.Text, tbImya.Text, tbOtchestvo.Text, tbAdres.Text, tbNumberPhone.Text);
                tbFamilia.Text = "";
                tbImya.Text = "";
                tbOtchestvo.Text = "";
                tbAdres.Text = "";
                tbNumberPhone.Text = "";
            }
            else
            {
               MessageBox.Show("Заполните поля", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            try
            {
                gridMenu.Rows.RemoveAt(gridMenu.SelectedCells[0].RowIndex);
            }
            catch
            {
                MessageBox.Show("Выделите строку", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnChange_Click(object sender, EventArgs e)
        {
            gridMenu.ReadOnly = false;
        }

        private void TbNumber_TextChanged(object sender, EventArgs e)
        {

        }

        private void TbName_TextChanged(object sender, EventArgs e)
        {

        }

        private void TbPatronymic_TextChanged(object sender, EventArgs e)
        {

        }

        private void TbAddress_TextChanged(object sender, EventArgs e)
        {

        }

        private void GridMain_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void TbSurname_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show(
               "Вы действительно хотите выйти?",
               "?",
               MessageBoxButtons.YesNo,
               MessageBoxIcon.Question,
               MessageBoxDefaultButton.Button2,
               MessageBoxOptions.DefaultDesktopOnly);

            if (result == DialogResult.Yes) Application.Exit();
        }

        private void lblNumber_Click(object sender, EventArgs e)
        {

        }
    }
}
