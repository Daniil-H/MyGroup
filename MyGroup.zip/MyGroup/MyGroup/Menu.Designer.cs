﻿namespace MyGroup
{
    partial class Menu
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblGrupa = new System.Windows.Forms.Label();
            this.gridMenu = new System.Windows.Forms.DataGridView();
            this.Surname = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.сName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Patronymic = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Address = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Number = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tbFamilia = new System.Windows.Forms.TextBox();
            this.lblSurname = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.lblPatronymic = new System.Windows.Forms.Label();
            this.tbImya = new System.Windows.Forms.TextBox();
            this.tbOtchestvo = new System.Windows.Forms.TextBox();
            this.lblAddress = new System.Windows.Forms.Label();
            this.tbAdres = new System.Windows.Forms.TextBox();
            this.lblNumber = new System.Windows.Forms.Label();
            this.tbNumberPhone = new System.Windows.Forms.TextBox();
            this.btnAdd = new System.Windows.Forms.Label();
            this.btnDelete = new System.Windows.Forms.Label();
            this.btnChange = new System.Windows.Forms.Label();
            this.btnExit = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.gridMenu)).BeginInit();
            this.SuspendLayout();
            // 
            // lblGrupa
            // 
            this.lblGrupa.AutoSize = true;
            this.lblGrupa.ForeColor = System.Drawing.Color.Black;
            this.lblGrupa.Location = new System.Drawing.Point(304, 8);
            this.lblGrupa.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblGrupa.Name = "lblGrupa";
            this.lblGrupa.Size = new System.Drawing.Size(126, 25);
            this.lblGrupa.TabIndex = 0;
            this.lblGrupa.Text = "Моя группа";
            // 
            // gridMenu
            // 
            this.gridMenu.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.gridMenu.BackgroundColor = System.Drawing.Color.White;
            this.gridMenu.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridMenu.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Surname,
            this.сName,
            this.Patronymic,
            this.Address,
            this.Number});
            this.gridMenu.GridColor = System.Drawing.Color.Black;
            this.gridMenu.Location = new System.Drawing.Point(11, 36);
            this.gridMenu.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.gridMenu.Name = "gridMenu";
            this.gridMenu.Size = new System.Drawing.Size(757, 275);
            this.gridMenu.TabIndex = 5;
            this.gridMenu.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.GridMain_CellContentClick);
            // 
            // Surname
            // 
            this.Surname.HeaderText = "Фамилия";
            this.Surname.Name = "Surname";
            // 
            // сName
            // 
            this.сName.HeaderText = "Имя";
            this.сName.Name = "сName";
            // 
            // Patronymic
            // 
            this.Patronymic.HeaderText = "Отчество";
            this.Patronymic.Name = "Patronymic";
            // 
            // Address
            // 
            this.Address.HeaderText = "Адрес";
            this.Address.Name = "Address";
            // 
            // Number
            // 
            this.Number.HeaderText = "Номер тел.";
            this.Number.Name = "Number";
            // 
            // tbFamilia
            // 
            this.tbFamilia.BackColor = System.Drawing.Color.White;
            this.tbFamilia.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbFamilia.ForeColor = System.Drawing.Color.Black;
            this.tbFamilia.Location = new System.Drawing.Point(125, 326);
            this.tbFamilia.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.tbFamilia.Name = "tbFamilia";
            this.tbFamilia.Size = new System.Drawing.Size(210, 31);
            this.tbFamilia.TabIndex = 6;
            this.tbFamilia.TextChanged += new System.EventHandler(this.TbSurname_TextChanged);
            // 
            // lblSurname
            // 
            this.lblSurname.AutoSize = true;
            this.lblSurname.ForeColor = System.Drawing.Color.Black;
            this.lblSurname.Location = new System.Drawing.Point(12, 328);
            this.lblSurname.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblSurname.Name = "lblSurname";
            this.lblSurname.Size = new System.Drawing.Size(110, 25);
            this.lblSurname.TabIndex = 7;
            this.lblSurname.Text = "Фамилия:";
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.ForeColor = System.Drawing.Color.Black;
            this.lblName.Location = new System.Drawing.Point(12, 369);
            this.lblName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(59, 25);
            this.lblName.TabIndex = 8;
            this.lblName.Text = "Имя:";
            // 
            // lblPatronymic
            // 
            this.lblPatronymic.AutoSize = true;
            this.lblPatronymic.ForeColor = System.Drawing.Color.Black;
            this.lblPatronymic.Location = new System.Drawing.Point(12, 408);
            this.lblPatronymic.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblPatronymic.Name = "lblPatronymic";
            this.lblPatronymic.Size = new System.Drawing.Size(111, 25);
            this.lblPatronymic.TabIndex = 9;
            this.lblPatronymic.Text = "Отчество:";
            // 
            // tbImya
            // 
            this.tbImya.BackColor = System.Drawing.Color.White;
            this.tbImya.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbImya.ForeColor = System.Drawing.Color.Black;
            this.tbImya.Location = new System.Drawing.Point(124, 367);
            this.tbImya.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.tbImya.Name = "tbImya";
            this.tbImya.Size = new System.Drawing.Size(211, 31);
            this.tbImya.TabIndex = 10;
            this.tbImya.TextChanged += new System.EventHandler(this.TbName_TextChanged);
            // 
            // tbOtchestvo
            // 
            this.tbOtchestvo.BackColor = System.Drawing.Color.White;
            this.tbOtchestvo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbOtchestvo.ForeColor = System.Drawing.Color.Black;
            this.tbOtchestvo.Location = new System.Drawing.Point(124, 406);
            this.tbOtchestvo.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.tbOtchestvo.Name = "tbOtchestvo";
            this.tbOtchestvo.Size = new System.Drawing.Size(211, 31);
            this.tbOtchestvo.TabIndex = 11;
            this.tbOtchestvo.TextChanged += new System.EventHandler(this.TbPatronymic_TextChanged);
            // 
            // lblAddress
            // 
            this.lblAddress.AutoSize = true;
            this.lblAddress.ForeColor = System.Drawing.Color.Black;
            this.lblAddress.Location = new System.Drawing.Point(12, 448);
            this.lblAddress.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblAddress.Name = "lblAddress";
            this.lblAddress.Size = new System.Drawing.Size(79, 25);
            this.lblAddress.TabIndex = 13;
            this.lblAddress.Text = "Адрес:";
            // 
            // tbAdres
            // 
            this.tbAdres.BackColor = System.Drawing.Color.White;
            this.tbAdres.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbAdres.ForeColor = System.Drawing.Color.Black;
            this.tbAdres.Location = new System.Drawing.Point(124, 446);
            this.tbAdres.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.tbAdres.Name = "tbAdres";
            this.tbAdres.Size = new System.Drawing.Size(211, 31);
            this.tbAdres.TabIndex = 12;
            this.tbAdres.TextChanged += new System.EventHandler(this.TbAddress_TextChanged);
            // 
            // lblNumber
            // 
            this.lblNumber.AutoSize = true;
            this.lblNumber.ForeColor = System.Drawing.Color.Black;
            this.lblNumber.Location = new System.Drawing.Point(12, 488);
            this.lblNumber.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblNumber.Name = "lblNumber";
            this.lblNumber.Size = new System.Drawing.Size(100, 25);
            this.lblNumber.TabIndex = 15;
            this.lblNumber.Text = "Номер т:";
            this.lblNumber.Click += new System.EventHandler(this.lblNumber_Click);
            // 
            // tbNumberPhone
            // 
            this.tbNumberPhone.BackColor = System.Drawing.Color.White;
            this.tbNumberPhone.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbNumberPhone.ForeColor = System.Drawing.Color.Black;
            this.tbNumberPhone.Location = new System.Drawing.Point(125, 486);
            this.tbNumberPhone.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.tbNumberPhone.Name = "tbNumberPhone";
            this.tbNumberPhone.Size = new System.Drawing.Size(210, 31);
            this.tbNumberPhone.TabIndex = 14;
            this.tbNumberPhone.TextChanged += new System.EventHandler(this.TbNumber_TextChanged);
            // 
            // btnAdd
            // 
            this.btnAdd.AutoSize = true;
            this.btnAdd.BackColor = System.Drawing.Color.White;
            this.btnAdd.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.btnAdd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdd.ForeColor = System.Drawing.Color.Black;
            this.btnAdd.Location = new System.Drawing.Point(658, 330);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(110, 27);
            this.btnAdd.TabIndex = 16;
            this.btnAdd.Text = "Добавить";
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.AutoSize = true;
            this.btnDelete.BackColor = System.Drawing.Color.White;
            this.btnDelete.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.btnDelete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDelete.ForeColor = System.Drawing.Color.Black;
            this.btnDelete.Location = new System.Drawing.Point(672, 410);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(96, 27);
            this.btnDelete.TabIndex = 17;
            this.btnDelete.Text = "Удалить";
            this.btnDelete.Click += new System.EventHandler(this.btnRemove_Click);
            // 
            // btnChange
            // 
            this.btnChange.AutoSize = true;
            this.btnChange.BackColor = System.Drawing.Color.White;
            this.btnChange.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.btnChange.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnChange.ForeColor = System.Drawing.Color.Black;
            this.btnChange.Location = new System.Drawing.Point(603, 371);
            this.btnChange.Name = "btnChange";
            this.btnChange.Size = new System.Drawing.Size(165, 27);
            this.btnChange.TabIndex = 18;
            this.btnChange.Text = "Редактировать";
            this.btnChange.Click += new System.EventHandler(this.btnChange_Click);
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.White;
            this.btnExit.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.btnExit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnExit.ForeColor = System.Drawing.Color.Black;
            this.btnExit.Location = new System.Drawing.Point(688, 488);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(80, 33);
            this.btnExit.TabIndex = 19;
            this.btnExit.Text = "Выход";
            this.btnExit.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(780, 531);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnChange);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.lblNumber);
            this.Controls.Add(this.tbNumberPhone);
            this.Controls.Add(this.lblAddress);
            this.Controls.Add(this.tbAdres);
            this.Controls.Add(this.tbOtchestvo);
            this.Controls.Add(this.tbImya);
            this.Controls.Add(this.lblPatronymic);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.lblSurname);
            this.Controls.Add(this.tbFamilia);
            this.Controls.Add(this.gridMenu);
            this.Controls.Add(this.lblGrupa);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ForeColor = System.Drawing.Color.Black;
            this.Margin = new System.Windows.Forms.Padding(6);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Menu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Моя группа";
            this.Load += new System.EventHandler(this.formMain_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gridMenu)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblGrupa;
        private System.Windows.Forms.DataGridView gridMenu;
        private System.Windows.Forms.TextBox tbFamilia;
        private System.Windows.Forms.Label lblSurname;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblPatronymic;
        private System.Windows.Forms.TextBox tbImya;
        private System.Windows.Forms.TextBox tbOtchestvo;
        private System.Windows.Forms.Label lblAddress;
        private System.Windows.Forms.TextBox tbAdres;
        private System.Windows.Forms.Label lblNumber;
        private System.Windows.Forms.TextBox tbNumberPhone;
        private System.Windows.Forms.Label btnAdd;
        private System.Windows.Forms.Label btnDelete;
        private System.Windows.Forms.Label btnChange;
        private System.Windows.Forms.Label btnExit;
        private System.Windows.Forms.DataGridViewTextBoxColumn Surname;
        private System.Windows.Forms.DataGridViewTextBoxColumn сName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Patronymic;
        private System.Windows.Forms.DataGridViewTextBoxColumn Address;
        private System.Windows.Forms.DataGridViewTextBoxColumn Number;
    }
}

